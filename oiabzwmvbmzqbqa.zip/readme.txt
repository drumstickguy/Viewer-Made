oiabzwmvbmzqbqa.exe by Executioner
a malware developed the course of almost a day
the non-safety version will destroy your PC when you run it, I'm not responsible for any damages
Credits to ArTicZera and Wipet for the HSL
creation date: May 27 2025
this malware contains flashing lights and earrape, not for epilepsy
Fun fact 1: oiabzwmvbmzqbqa means gastroenteritis in Caeser cipher
Fun fact 2: the MBR text comes from Glitter Force Doki Doki S2 E9, at the start of the episode





























































I know you will put this into the skidded folder in your trash ass database, FelloBoiYuuka, do something else instead of being a malware fan and leaking faces
Aero, stop simping for pankoza and check dates before commenting anything.