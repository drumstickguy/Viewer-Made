▓█████▄  ▄▄▄       ██▀███   ██ ▄█▀ ███▄    █ ▓█████   ██████   ██████      ▓█████ ▒██   ██▒▓█████ 
▒██▀ ██▌▒████▄    ▓██ ▒ ██▒ ██▄█▒  ██ ▀█   █ ▓█   ▀ ▒██    ▒ ▒██    ▒      ▓█   ▀ ▒▒ █ █ ▒░▓█   ▀ 
░██   █▌▒██  ▀█▄  ▓██ ░▄█ ▒▓███▄░ ▓██  ▀█ ██▒▒███   ░ ▓██▄   ░ ▓██▄        ▒███   ░░  █   ░▒███   
░▓█▄   ▌░██▄▄▄▄██ ▒██▀▀█▄  ▓██ █▄ ▓██▒  ▐▌██▒▒▓█  ▄   ▒   ██▒  ▒   ██▒     ▒▓█  ▄  ░ █ █ ▒ ▒▓█  ▄ 
░▒████▓  ▓█   ▓██▒░██▓ ▒██▒▒██▒ █▄▒██░   ▓██░░▒████▒▒██████▒▒▒██████▒▒ ██▓ ░▒████▒▒██▒ ▒██▒░▒████▒
 ▒▒▓  ▒  ▒▒   ▓▒█░░ ▒▓ ░▒▓░▒ ▒▒ ▓▒░ ▒░   ▒ ▒ ░░ ▒░ ░▒ ▒▓▒ ▒ ░▒ ▒▓▒ ▒ ░ ▒▓▒ ░░ ▒░ ░▒▒ ░ ░▓ ░░░ ▒░ ░
 ░ ▒  ▒   ▒   ▒▒ ░  ░▒ ░ ▒░░ ░▒ ▒░░ ░░   ░ ▒░ ░ ░  ░░ ░▒  ░ ░░ ░▒  ░ ░ ░▒   ░ ░  ░░░   ░▒ ░ ░ ░  ░
 ░ ░  ░   ░   ▒     ░░   ░ ░ ░░ ░    ░   ░ ░    ░   ░  ░  ░  ░  ░  ░   ░      ░    ░    ░     ░   
   ░          ░  ░   ░     ░  ░            ░    ░  ░      ░        ░    ░     ░  ░ ░    ░     ░  ░
 ░                                                                      ░                         

Darkness.exe is a trojan that messes with your PC's performance by placing GDI's which are system graphics, modifying your PC extensively.

Made by: indoamanso and CYBERWARE
Coded in: C#, .vbs & .bat

indoamanso.'s channel: https://www.youtube.com/channel/UCrUCvJJ5qbYvC8U5mRgsCQQ
My channel: https://www.youtube.com/@CYBERWARE-TECH (CYBERWARE).