INVESTIGATIGATING.exe
by CriticForInterpreting

A virus that replace files and draw on screen.