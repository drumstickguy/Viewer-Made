nnn.exe by Tubercomiosis

WARNING: This is a malware.
If you are on a physical environment, please run the version with the .safety branch.
It's pretty short.
My first malware without source code, but NO skid! :D

First payload is hypnotic.
I'm NOT responsible for ANY damages.


YouTube: @tubercomithedude