dyporssions.exe
made by Minhgotuknight19 / LuK3 archive

Credits to N17Pro3426 for the SpiltBlt
Credits to JhoPro/ArTicZera and wipet for the HSL
Credits to EthernalVortex for the PRGBQUAD

























Hi I am Wynn, b9tinu (yedb0y33k), Marlon2210