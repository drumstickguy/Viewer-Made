 ██████╗      ██╗██╗  ██╗████████╗██╗   ██╗███████╗   ███████╗██╗  ██╗███████╗
██╔════╝      ██║╚██╗██╔╝╚══██╔══╝██║   ██║██╔════╝   ██╔════╝╚██╗██╔╝██╔════╝
██║  ███╗     ██║ ╚███╔╝    ██║   ██║   ██║█████╗     █████╗   ╚███╔╝ █████╗  
██║   ██║██   ██║ ██╔██╗    ██║   ╚██╗ ██╔╝██╔══╝     ██╔══╝   ██╔██╗ ██╔══╝  
╚██████╔╝╚█████╔╝██╔╝ ██╗   ██║    ╚████╔╝ ███████╗██╗███████╗██╔╝ ██╗███████╗
 ╚═════╝  ╚════╝ ╚═╝  ╚═╝   ╚═╝     ╚═══╝  ╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                                              
Malware name: gjxtve.exe
Malware type: Destructive
Skidded? Yes, it's skidded
Created by: Nyfol2290
Description: This is a skidded malware, and Pilliman game for kernel that I found when the MBR is erased =)