you'll need net framework 3.5 or higher for this to work
also epilepsy warning
by ChrisRM_380
also, this thing is heavily inspired by infiniteblue