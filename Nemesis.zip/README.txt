 _   _ ______ __  __ ______  _____ _____  _____ 
| \ | |  ____|  \/  |  ____|/ ____|_   _|/ ____|
|  \| | |__  | \  / | |__  | (___   | | | (___  
| . ` |  __| | |\/| |  __|  \___ \  | |  \___ \ 
| |\  | |____| |  | | |____ ____) |_| |_ ____) |
|_| \_|______|_|  |_|______|_____/|_____|_____/ 

------------------------------------------------
✧ Information ✧
Developer: CYBERWARE
Coded in: C#
Version: 1.0
Category: Trojan-GDI.Win32
Compatible platforms: Windows XP, Vista, 7, 8.1, 10 & 11.
Execution requirement: .NET Framework 4.0
Destructive? Yes
------------------------------------------------
⊗ Photosensitive seizure warning ⊗
Includes specific graphic effects? Yes
Contains loud or intense audio? Yes

☢ Attention ☢
I (CYBERWARE) am not responsible for any damages or losses resulting from use.

☞ Recommendation ☞
For testing and research purposes, I strongly recommend using virtual machines, such as VMware or VirtualBox.
------------------------------------------------
⇩ Networks ⇩
♤ YouTube: [CYBERWARE-TECH] (https://www.youtube.com/@CYBERWARE-TECH)
❀ GitHub: [CYBERWARE-SECURITY] (https://github.com/CYBERWARE-SEGURITY)  
✯ Discord: t3nx1l  
☁ My site: [CyberWareCursos] (https://linkfly.to/CyberWareCursos)
------------------------------------------------