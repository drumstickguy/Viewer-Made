HorrorTubbies (MrsMajor 3.0 style)
I created this virus for fun, but it's also destructive
If you want to test it, use a VM, not a real PC
Works best on Windows 10 x64
Runtimes required: .NET Framework 4.0 or later
I will probably not update the malware, but maybe...